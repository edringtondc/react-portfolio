**To delete a user**

This example deletes a user.

Command::

  aws cognito-idp delete-user --access-token ACCESS_TOKEN
  
